package com.example.learnJava.conditionalOnProperty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConditionalOnPropertyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConditionalOnPropertyApplication.class, args);
	}

}
